CSI2772 C++ Project

Student name: Arman Dogru
Student number: 300168151

Student name: Talya Vuruskaner
Student number: 300108389

We used Clion IDE to develop our Card Game. We have created a Card class, which derives Blue, Chili, Stink, Green, Soy, Black, Red and Garden classes; a Chain class, Deck class, DiscardPile class, TradeArea class, Hand class, Player class, Table class, CardFactory class and a Main class to play the card game.

Card class includes virtual int getCardsPerCoin(int coins) function, which checks how many cards are necessary to receive the corresponding number of coins; virtual string getName() function, which will returns\ the name of the card; virtual void print(ostream& out) function, which will insert the first char of the card into the output stream; and also a global stream insertion operator to print objects of such a class which implements the “Virtual Friend Function Idiom”.

Chain class includes the Chain<T>& operator+=(Card*) function, which will add a card to the Chain; int sell() function, which will count the number of cards in the chain and return the number of coins with the help of function Card::getCardsPerCoin; an insertion operator (friend) to print Chain on an std::ostream; and Chain(istream&, const CardFactory*) function which is a constructor.

Deck class includes Card* draw() function, which will return and remove the top card from the deck; an insertion operator (friend) to insert all the cards in the deck to an std::ostream; and also Deck(istream&, const CardFactory*) function which is a constructor.

DiscardPile class holds cards in a std::vector and is similar to Deck. It includes the DiscardPile& operator+=(Card*) function, which will discard the card to the pile; Card* pickUp() function which will return and remove the top card from discard pile; Card* top() function which will return but will not remove the top card from discard pile; void print(std::ostream&) function for insertion of all the cards in the DiscardPile to an std::ostream; and an insertion operator (friend) for insertion just the top card of the discard pile to an std::ostream; and also DiscardPile(istream&, const CardFactory*) function which is a constructor.

TradeArea class holds cards in a std::list. It includes the TradeArea& operator+=(Card*) function to add the card to the trade area; bool legal(Card*) function which will return true if the card can be added to TradeArea; Card* trade(string) function which will remove a card of the corresponding bean name; int numCards() function which will return the number of cards currently in the trade area; and the insertion operator (friend) to insert all the cards of the trade area to an std::ostream; and also TradeArea(istream&, const CardFactory*) function which is a constructor.

Hand class includes Hand& operator+=(Card*) function which will add the card to rear of the hand; Card* play() function which will return and remove the top card from player's hand; Card* top() function which will return but will not remove the top card from player's hand; Card* operator[](int) function which will return and remove the Card at a specific index; and an insertion operator (friend) to print Hand on an std::ostream; and also Hand(istream&, const CardFactory*) function which is a constructor.

Player class includes Player(std::string&) function which is a constructor that creates a Player; std:string getName() function which gets the name of the player; int getNumCoins() function which will get the number of coins currently the player has; Player& operator+=(int) function which will add a number of coins; int getMaxNumChains() function which will return either 2 or 3; int getNumChains() function which will return the number of non-zero chains; Chain& operator[](int i) function which will return the chain at position i; void buyThirdChain() function which will add an empty third chain to the player for three coins. The functions reduces the coin count for the player by two; void printHand(std::ostream&, bool) function which prints the top card of the player's hand or all of the player's hand to ostream; and the insertion operator (friend) to print a Player to an std::ostream; and also Player(istream&, const CardFactory*) function which is a constructor.

Table class manages all the game components. It will hold two objects of type Player, Deck and DiscardPile, as well as the TradeArea.
It includes bool win(std::string&) function which returns true when a player has won; void printHand(bool) function which prints the top card of the player's hand (with argument false) or all of the player's hand (with argument true); and the insertion operator (friend) to print a Table to an std::ostream; and also Table(istream&, const CardFactory*) function which is a constructor.

The card factory serves as a factory for all bean cards. CardFactory class includes constructor function in which all the cards need to be created in the numbers needed for the game; static CardFactory* getFactory() function which returns a pointer to the only instance of CardFactory; Deck getDeck() function which returns a deck with all 104 bean cards. 

And finally a Main function to play the card game.